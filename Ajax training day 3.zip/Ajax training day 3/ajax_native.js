function GenericAjaxFunc(url,functiontoBeCalled)
{
                  var AJAX = null;
                  try
                 {
                        AJAX = new XMLHttpRequest();
                 }
                 catch (trymicrosoft)
                 {
                        try
                              {
                                    AJAX = new ActiveXObject("Msxml2.XMLHTTP");
                              }
                        catch (othermicrosoft)
                              {
                                    try
                                          {
                                                AJAX = new ActiveXObject("Microsoft.XMLHTTP");
                                          }
                                    catch (failed)
                                          {
                                                AJAX=null;
                                                if(window.confirm("Internet Explorer Settings on your machine are not optimized for Global IPP Workflow. Please click OK and you'll be directed to a page with four easy steps to resolve this issue; In case you need further assistance please contact your IPP COE or log a case with Support team.") == true)
                                          {
                                                window.location.replace("https://libraries.ge.com/download?fileid=424048687101&entity_id=26293475101&sid=101");
                                          }
                                          }
                              }
                 }

            AJAX.onreadystatechange = function()
                  {
                        if (AJAX.readyState==4 || AJAX.readyState=="complete")
                        {
                              functiontoBeCalled(AJAX.responseXML);
                        }
                  };

            AJAX.open("GET", url, true);
            AJAX.send(null);
}
