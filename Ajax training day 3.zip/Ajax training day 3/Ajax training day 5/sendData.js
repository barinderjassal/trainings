function sendData()
	{
		var xmlPost = "<sc_record>";
			xmlPost+= "<logged>502135738</logged>";
			xmlPost+= "<name>"+document.getElementById('nametext').value+"</name>";
			xmlPost+= "<empid>"+document.getElementById('empid').value+"</empid>";
			xmlPost+= "<qual>"+document.getElementById('qual').value+"</qual>";
			xmlPost+= "<ment>"+document.getElementById('mentor').value+"</ment>";
			xmlPost+= "<self>"+document.getElementById('yrself').value+"</self>";
			xmlPost+= "</sc_record>";
		var strURL = "https://libraries.ge.com/scxml/xmlpost/sup_process_df_xml_post.asp?map_id=472562&entity_id=381743&entity_type=4"
		
		AjaxPostingMsg(xmlPost,strURL,"Data saved");
	
	}
function AjaxPostingMsg(strXMlToPost,strURL,strMessage)
{
	var AJAX=null;
	if(window.XMLHttpRequest)
	{
		AJAX=new XMLHttpRequest();
	}
	else
	{
		AJAX=new ActiveXObject("Microsoft.XMLHTTP");
	}
	if(AJAX==null)
	{
		alert("Yourbrowserdoesn'tsupportAJAX.");
		return false;
	}
		AJAX.onreadystatechange=function()
		{
			if(AJAX.readyState==4||AJAX.readyState=="complete")
			{
				debugger;
				if(AJAX.responseText.indexOf('<errorcode>0</errorcode>')>0)
				{
					alert("Your changes has been saved");
				}
				else
				{
				//	alert(strXMlToPost);
					
					alert("ErrorinPosting.");
					alert("Error Description:\n"+AJAX.responseText);
				}
			}
		}
	AJAX.open("POST",strURL,true);
	AJAX.send(strXMlToPost);
}
