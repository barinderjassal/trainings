function GenericAjaxFunc(url)
{
	var AJAX=null;
	try
	 {
	  AJAX = new XMLHttpRequest();
	 }
	 catch (trymicrosoft)
	 {
		  try
		  {
		   AJAX = new ActiveXObject("Msxml2.XMLHTTP");
		  }
		  catch (othermicrosoft)
		  {
			   try
			   {
				AJAX = new ActiveXObject("Microsoft.XMLHTTP");
			   }
			   catch (failed)
			   {
				AJAX=null;
			   }
		  }
	 }

	//AJAX.onreadystatechange = functiontoBeCalled;
	AJAX.onreadystatechange = function()
	{
		alert(AJAX.readyState);
		/*
		Holds the status of the XMLHttpRequest. Changes from 0 to 4: 
			0: request not initialized 
			1: server connection established
			2: request received 
			3: processing request 
			4: request finished and response is ready
		
		
		
		*/
		
		
		if (AJAX.readyState==4 || AJAX.readyState=="complete")
		{
			var dataxml = AJAX.responseXML;
			rowXml = dataxml.getElementsByTagName("ViewAll")[0].getElementsByTagName("ROW");
			alert(rowXml.length);
			document.getElementById('nametext').value = rowXml[1].getElementsByTagName("SC_DF_FIELD_1")[0].childNodes[0].nodeValue;
			/*
			document.getElementById('empid').value
			document.getElementById('qual').value
			document.getElementById('yrself').value
			*/
			
		}
	};

	AJAX.open("GET", url, true);
	AJAX.send(null);
}

function fillData()
	{
		var url ="http://libraries.ge.com/scweb/dataforms/sup_dataform_viewall.asp?prod_id=251837&form_id=381743&xsl=geTemplate";
		GenericAjaxFunc(url)	
			
	}

