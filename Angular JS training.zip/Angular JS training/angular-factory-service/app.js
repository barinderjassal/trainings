// MODULE
var app = angular.module('app', []);

// CONTROLLERS

app.controller('MyController', ['$scope', function ($scope) {
    
    $scope.myVar = "This is from Controller";
    console.log('controller here');
}]);

// SERVICE

angular.module('app');

.service('movie', function () {
  this.title = 'The Matrix';
});

.controller('MyController', function (movie) {
  expect(movie.title).toEqual('The Matrix');
});


// FACTORY

angular.module('app');

.factory('movie', function () {
  return {
    title: 'The Matrix';
  }
});

