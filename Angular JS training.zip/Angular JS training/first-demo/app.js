var app = angular.module('myApp', []);

app.controller('MyController', function($scope){

    $scope.firstName = 'Sachin';
    $scope.lastName='Kumar';

    // Number, String, Boolean, Array, Object, Function, Undefined

    $scope.myNumber = 99;

    $scope.myBoolean = true;    

    $scope.myArr = [];

    $scope.myObj = {
        name: 'Sachin',
        id: 12,
        age: 1234
    };
    $scope.myArr.push($scope.myObj);
//    $scope.myArr.push($scope.myObj);
console.log($scope.myArr);
    console.log($scope.myObj.name);

    var fullName = $scope.firstName + ' ' + $scope.lastName;

//    $scope.blockButton = false; 
    
    $scope.myFunction = function () {
        
        $scope.myNumber++;
//        $scope.blockButton = true; 
    };

});