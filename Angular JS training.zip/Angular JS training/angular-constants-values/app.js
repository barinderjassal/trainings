var app = angular.module('myApp', []);

app.factory('myFactory', [function(){
    var obj = {
        
        counter: 0,
        incrementCounter: incrmentCounterfn
        
    };
    
    function incrmentCounterfn () {
        obj.counter++;
    }
    
    return obj;
}])

app.service('myService', [function(){
    
    this.counter = 0;
    
    this.incrmentCounter = incrmentCounterfn;
    
    function incrmentCounterfn () {
        this.counter++;
    }
    
    
}]);

app.controller('MyController', ['$scope', 'myFactory','myService', function($scope, myFactory, myService) {
   
    console.log(myFactory);
    console.log(myService);
    
    
}]);


