// MODULE
var app = angular.module('app', []);

// FACTORY

app.factory('myFactory', function(){
    var obj = {
        counter: 0,
        increment: incrementFn
    };
    return obj;

    function incrementFn () {
        obj.counter++;
    }

})

// SERVICE

app.service('myService', function(){

    this.counter = 0

    this.increment = function () {
        this.counter++;
    }
})

// CONTROLLERS

app.controller('MyFirstController', ['$scope','myFactory','myService', function ($scope, myFactory, myService) {

    $scope.printValues = function () {

        console.log('\n MyFirstController');
        console.log('myFactory.counter: '+ myFactory.counter);
        console.log('myService.counter: ' + myService.counter);

    };
    $scope.printValues();

    $scope.incrementFactory = function () {
        myFactory.increment();
    };

    $scope.incrementService = function () {
        myService.increment();
    };

}]);

app.controller('MySecondController', ['$scope','myFactory','myService', function ($scope, myFactory, myService) {

    $scope.printValues = function () {

        console.log('\n MySecondController');
        console.log('myFactory.counter: '+ myFactory.counter);
        console.log('myService.counter: ' + myService.counter);

    };
    $scope.printValues();

    $scope.incrementFactory = function () {
        myFactory.increment();
    };

    $scope.incrementService = function () {
        myService.increment();
    };

}]);


