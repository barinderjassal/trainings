// MODULE
var app = angular.module('app', []);

// CONTROLLERS

app.controller('MyController', ['$scope', function ($scope) {

    $scope.myVar = "myVar from Controller";
    console.log('from MyController ');
    console.log($scope);

}]);

app.directive('mySecondDirective', [function(){
    return {

        restrict: 'E',
        scope: {},
        template: '<div>Hello I am from mySecondDirective</div>',
        transclude: true,
        controller: function($scope){
            console.log('directive controller');
            
        }
    }
}]);

/*
app.directive('myFirstDirective', [function(){
    return {

        restrict: 'E', // could be EACM i.e. Element, Attribute, Class, Comment respectively
        scope: false, // could be false(default case), true, or Object hash 
        //        replace: true,
        template: '<div style="color:green;">myFirstDirective: {{myVar}}<input type="text" ng-model="myVar"></div>',
        link: function(scope, ele, attrs, cntrlr) {
            console.log('in link myFirstDirective');
            console.log(scope);
        },
        compile: function(ele, attrs) {
            console.log('compile');
            return {
                pre: function() {
                    console.log('pre');
                },
                post: function(scope, ele, attrs, cntrlr) {
                    console.log('post');
                    console.log(scope);
                    console.log(ele);
                    console.log(attrs);
                    console.log(cntrlr);
                }
            };
        },
        controller: function($scope){
            console.log('directive controller');
            console.log($scope);
        }

    };
}]);
*/


