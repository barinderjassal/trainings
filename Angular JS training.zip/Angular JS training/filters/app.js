// MODULE
var app = angular.module('app', []);

// CONTROLLERS

app.controller('MyController', ['$scope','$filter', function ($scope, $filter) {
    
    $scope.myArr = ['Sachin'];
    
    $scope.addToList = function () {
        
        $scope.newName = $filter('uppercase')($scope.newName);
//        $scope.myArr.unshift($scope.newName);
        $scope.myArr.push($scope.newName);
        $scope.newName = '';
    };
    
}]);



