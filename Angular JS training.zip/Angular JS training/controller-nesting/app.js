// MODULE
var app = angular.module('app', []);

// CONTROLLERS

app.controller('OuterController', function ($scope) {

    console.log('OuterController controller here');
    console.log($scope.firstName);

});

app.controller('InnerController', function ($scope) {

    console.log('InnerController controller here');
    
});