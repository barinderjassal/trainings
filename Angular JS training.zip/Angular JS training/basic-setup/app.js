// MODULE
var app = angular.module('app', []);

// CONTROLLERS

app.controller('MyController', ['$scope', function ($scope,$filter) {
    $scope.Demo="";
    $scope.myVar = "This is from Controller";
    console.log('controller here');
}]);



