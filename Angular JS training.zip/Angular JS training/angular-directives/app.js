// MODULE
var app = angular.module('app', []);

app.controller('MyController', ['$scope', function ($scope) {
    
    $scope.myVar = "This is from Controller";
    console.log('controller here');
}]);


// DIRECTIVES

app.directive('demo1', function(){
    return {
        restrict: 'E',
        compile: function(elm, attrs){
            console.log('compile1');
            return {
                pre: function (scope, element, attrs) {
                    console.log('pre1');
                },
                post: function (scope, element, attrs) {
                    console.log('post1')
                }
            };
        }
        

    }
});

app.directive('demo2', function(){
    return {
        restrict: 'E',
        compile: function(elm, attrs){
            console.log('compile2');
            return {
                pre: function (scope, element, attrs) {
                    console.log('pre2');
                },
                post: function (scope, element, attrs) {
                    console.log('post2')
                }
            };
        }
        

    }
});

app.directive('demo3', function(){
    return {
        restrict: 'E',
        compile: function(elm, attrs){
            console.log('compile3');
            return {
                pre: function (scope, element, attrs) {
                    console.log('pre3');
                },
                post: function (scope, element, attrs) {
                    console.log('post3')
                }
            };
        }
        

    }
});


